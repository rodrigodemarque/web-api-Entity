using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using MinhaPrimeiraAPI.Context;
using MinhaPrimeiraAPI.Entities;

namespace MinhaPrimeiraAPIMigration.Controllers;

[ApiController]
[Route("[controller]")]
public class EstoqueController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public EstoqueController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet()]
    public async Task<ActionResult<List<Estoque>>> GetAll()
    {
        return Ok(await _context.Estoques.Include(e => e.Produto).ToListAsync());
    }

    [HttpPost("AddEstoque")]
    public async Task<ActionResult<Estoque>> AddEstoque([FromBody] Estoque model)
    {
        try
        {
            if (model == null)
                return BadRequest("Os dados do estoque não foram enviados");
            if (model.ProdutoId == 0)
                return BadRequest("Não é possível incluir um estoque sem um produto");

            if (!await VerificaExistenciaProduto(model.ProdutoId))
                return BadRequest($"Não foi possível localizar o produto {model.ProdutoId}");

            var novoEstoque = new Estoque
            {
                ProdutoId = model.ProdutoId,
                Quantidade = model.Quantidade
            };

            _context.Estoques.Add(novoEstoque);
            await _context.SaveChangesAsync();
            return Ok(novoEstoque);
        }
        catch (Exception)
        {

            throw;
        }

    }
    private async Task<bool> VerificaExistenciaProduto(int id)
    {
        var produto = await _context.Produtos.FirstOrDefaultAsync(e => e.Id == id);

        if (produto == null)
            return false;

        return true;
    }
}
