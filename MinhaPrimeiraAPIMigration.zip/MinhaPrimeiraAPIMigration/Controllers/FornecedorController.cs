using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MinhaPrimeiraAPI.Context;
using MinhaPrimeiraAPI.Entities;
using MinhaPrimeiraAPIMigration.Dto;

namespace MinhaPrimeiraAPIMigration.Controllers;

[ApiController]
[Route("api/fornecedores")]
public class FornecedorController : ControllerBase
{
    public readonly ApplicationDbContext _context;

    public FornecedorController(ApplicationDbContext context)
    {
        _context = context;
    }



    [HttpGet()]
    public async Task<ActionResult<List<Fonecedor>>> ObterFornecedores()
    {
        return Ok(await _context.Fornecedores
        .Include(f => f.Produtos)
    .Select(f => new FornecedorDto
    {
        Id = f.Id,
        Nome = f.Nome,
        Produtos = f.Produtos.Select(p => new ProdutoDto
        {
            Id = p.Id,
            Nome = p.Nome
        }).ToList()
    })
    .FirstOrDefaultAsync());
    }

    [HttpPost("Add-Fornecedor")]
    public async Task<ActionResult<Fonecedor>> AddFornecedor(string nome)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(nome))
                return BadRequest("Dados para inclusão faltando");
            var novoFornecedor = new Fonecedor { Nome = nome };
            if (novoFornecedor == null)
                return BadRequest("Problema interno - contato suporte");

            _context.Fornecedores.Add(novoFornecedor);
            await _context.SaveChangesAsync();

            return Ok(novoFornecedor);
        }
        catch (Exception)
        {

            throw;
        }
    }


}

