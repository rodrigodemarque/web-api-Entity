using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MinhaPrimeiraAPI.Context;
using MinhaPrimeiraAPI.Entities;
using MinhaPrimeiraAPIMigration.Dto;

namespace MinhaPrimeiraAPIMigration.Controllers;

[ApiController]
[Route("api/produtos")]
public class ProdutoController : ControllerBase
{
    public readonly ApplicationDbContext _context;

    public ProdutoController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet()]
    public async Task<ActionResult<IEnumerable<Produto>>> ObterProdutos()
    {
        return Ok(await _context.Produtos
        .Include(e => e.Fornecedor)
        .Select(e => new ProdutoDto
        {
            Id = e.Id,
            Nome = e.Nome,
            Preco = e.Preco,
            Inativo = e.Inativo,
            FornecedorId = e.FornecedorId,
            Fornecedor = new FornecedorDto
            {
                Id = e.Fornecedor.Id,
                Nome = e.Fornecedor.Nome
            }
        })
        .ToListAsync());
    }

    [HttpPost("Add-Produto")]
    public async Task<ActionResult<Produto>> AddProdruto([FromBody] Produto model)
    {
        try
        {
            if (model == null)
                return BadRequest("Verifique se todos os campos estão preenchidos!");
            if (model.Preco == 0)
                return BadRequest("O preço não pode ser ZERO!");
            if (!await VerificaExistenciaFornecedor(model.FornecedorId))
                return BadRequest($"Fornecedor código {model.FornecedorId} não encontrado!");

            var novoProduto = new Produto
            {
                Nome = model.Nome,
                Preco = model.Preco,
                Inativo = model.Inativo,
                FornecedorId = model.FornecedorId
            };

            _context.Produtos.Add(novoProduto);
            await _context.SaveChangesAsync();
            return Ok(novoProduto);

        }
        catch (Exception ex)
        {
            return BadRequest(ex);
        }

    }
    private async Task<bool> VerificaExistenciaFornecedor(int id)
    {
        try
        {
            var fornecedor = await _context.Fornecedores.FirstOrDefaultAsync(e => e.Id == id);
            if (fornecedor == null)
                return false;

            return true;
        }
        catch (Exception)
        {

            throw;
        }

    }
}
