namespace MinhaPrimeiraAPI.Entities;

public class Produto
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public decimal Preco { get; set; }
    public bool Inativo { get; set; }
    public int FornecedorId { get; set; }
    public virtual Fonecedor Fornecedor { get; set; }        
}
