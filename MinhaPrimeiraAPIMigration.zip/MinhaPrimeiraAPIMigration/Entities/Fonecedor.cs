namespace MinhaPrimeiraAPI.Entities;

public class Fonecedor
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public DateTime DataCadastro { get; set; }

    public virtual List<Produto> Produtos { get; set; }

    public Fonecedor()
    {
        DataCadastro = DateTime.Now;
    }
}
