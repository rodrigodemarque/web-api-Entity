using MinhaPrimeiraAPI.Entities;

namespace MinhaPrimeiraAPIMigration.Dto;

public class EstoqueDto
{
    public int Id { get; set; }
    public decimal Quantidade { get; set; }
    public int ProdutoId { get; set; }
    public ProdutoDto Produto { get; set; }
}
