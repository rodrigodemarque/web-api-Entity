
namespace MinhaPrimeiraAPIMigration.Dto;

public class ProdutoDto
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public decimal Preco { get; set; }
    public bool Inativo { get; set; }
    public int FornecedorId { get; set; }
    public FornecedorDto Fornecedor { get; set; }

}
