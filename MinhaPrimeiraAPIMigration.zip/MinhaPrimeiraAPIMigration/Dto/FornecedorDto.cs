using MinhaPrimeiraAPI.Entities;

namespace MinhaPrimeiraAPIMigration.Dto
{
    public class FornecedorDto
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public DateTime DataCadastro { get; set; }
        public List<ProdutoDto> Produtos { get; set; }
    }
}