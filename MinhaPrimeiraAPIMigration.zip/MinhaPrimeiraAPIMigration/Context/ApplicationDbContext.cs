
using Microsoft.EntityFrameworkCore;
using MinhaPrimeiraAPI.Entities;

namespace MinhaPrimeiraAPI.Context;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options) { }

    public DbSet<Fonecedor> Fornecedores { get; set; }
    public DbSet<Produto> Produtos { get; set; }
    public DbSet<Estoque> Estoques { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Produto>().HasKey(e => e.Id);
        modelBuilder.Entity<Fonecedor>().HasKey(e => e.Id);
        modelBuilder.Entity<Estoque>().HasKey(e => e.Id);

        modelBuilder.Entity<Produto>().Property(e => e.Preco).HasPrecision(18, 5);
        modelBuilder.Entity<Estoque>().Property(e => e.Quantidade).HasPrecision(18, 5);

        modelBuilder
        .Entity<Produto>()
        .HasOne(e => e.Fornecedor)//Um produto tem um fornecedor
        .WithMany(e => e.Produtos)//um frnecedor tem varios produtos
        .HasForeignKey(e => e.FornecedorId)//Indica o relacionamento entre o produto e o fornecedor
        .IsRequired(); //Um produto precisa ter um fornecedor

        modelBuilder
        .Entity<Estoque>()
        .HasOne(e => e.Produto)//Um estoque tem um produto
        .WithOne()//Um produto tem um estoque
        .HasForeignKey<Estoque>(e => e.ProdutoId)//Indica o relacionamento entre o estoque e o produto
        .IsRequired();//Um estoque precisa ter um produto

        base.OnModelCreating(modelBuilder);
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
            optionsBuilder.UseSqlServer("Default");
        base.OnConfiguring(optionsBuilder);
    }

}
    
        
    
