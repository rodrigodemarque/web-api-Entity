using System.ComponentModel.DataAnnotations;

namespace MinhaPrimeiraAPI.Models;

public class Cliente
{
    [Key]
    public int Id { get; set; }
    [MaxLength(255)]
    [Required(ErrorMessage ="Este campo é obrigatório")]
    public string Nome { get; set; }
    [Required(ErrorMessage ="Este campo é obrigatório")]
    public int Idade { get; set; }
    [Required(ErrorMessage ="Este campo é obrigatório")]
    public DateTime DataNascimento { get; set; }
    [MaxLength(15)]
    [Required(ErrorMessage ="Este campo é obrigatório")]
    public string Sexo { get; set; }
    [MaxLength(255)]
    [Required(ErrorMessage ="Este campo é obrigatório")]
    public string Endereco { get; set; }
    [MaxLength(50)]
    public string? Complemento { get; set; }
    [MaxLength(20)]
    [Required(ErrorMessage ="Este campo é obrigatório")]
    public string Numero { get; set; }
    [Required(ErrorMessage ="Este campo é obrigatório")]
    public int CEP { get; set; }
    [MaxLength(255)]
    [Required(ErrorMessage ="Este campo é obrigatório")]
    public string Cidade { get; set; }
    [MaxLength(2)]
    [Required(ErrorMessage ="Este campo é obrigatório")]
    public string Estado { get; set; }
    [MaxLength(20)]
    public string? Fone { get; set; }

}
