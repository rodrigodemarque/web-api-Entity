using System.Threading.Tasks;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MinhaPrimeiraAPI.Context;
using MinhaPrimeiraAPI.Models;

namespace MinhaPrimeiraAPI.Controllers;

[ApiController]
[Route("[Controller]")]
public class ClienteController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public ClienteController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet("GetAll")]
    public async Task<ActionResult<Cliente>> GetAll()
    {
        return Ok(await _context.Clientes.ToListAsync());
    }

    [HttpPost("Add")]
    public async Task<ActionResult<Cliente>> Post([FromBody] Cliente model)
    {
        if (!ModelState.IsValid)
            return BadRequest();
        await _context.AddAsync(model);
        await _context.SaveChangesAsync();
        return Ok(model);
    }

    [HttpPut("Update/{id:int}")]
    public async Task<ActionResult<Cliente>> Put(int id, Cliente model)
    {
        var cliente = await _context.Clientes.FindAsync(id);
        if (cliente == null)
            return NotFound();

        cliente.Nome = model.Nome;
        cliente.Idade = model.Idade;
        cliente.DataNascimento = model.DataNascimento;
        cliente.Sexo = model.Sexo;
        cliente.Endereco = model.Endereco;
        cliente.Complemento = model.Complemento;
        cliente.Numero = model.Numero;
        cliente.CEP = model.CEP;
        cliente.Cidade = model.Cidade;
        cliente.Estado = model.Estado;
        cliente.Fone = model.Fone;

        _context.Clientes.Update(cliente);
        await _context.SaveChangesAsync();
        return Ok(cliente);
    }


    [HttpDelete("Delete/{id:int}")]
    public async Task<ActionResult> Delete(int id)
    {
        var cliente = await _context.Clientes.FindAsync(id);
        if (cliente == null)
            return NotFound();

        _context.Clientes.Remove(cliente);
        await _context.SaveChangesAsync();
        return Ok("Cliente Removido com Sucesso!!!");

    }
}

   
